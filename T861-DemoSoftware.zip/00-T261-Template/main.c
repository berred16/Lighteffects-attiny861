#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>

//******************************************************************************
// Universallauflicht mit Atiny261/461/861
// Anschlussbelegung:
//                         ____   ____
//       Drehschalter 8  *|PB0 \_/ PA0|* 20 LED
//       Drehschalter 4  *|PB1     PA1|* 19 LED
//       Drehschalter 2  *|PB2     PA2|* 18 LED
//       Drehschalter 1  *|PB3     PA3|* 17 LED
//                +5V 5  *|VCC     GND|* 16 GND
//                GND 6  *|GND    AVCC|* 15 +5V
//         Poti (ADC7)7  *|PB4     PA4|* 14 LED
//                PB5 8  *|PB5     PA5|* 13 LED
//                PB6 9  *|PB6     PA6|* 12 LED
//  (reset) +5V -10k- 10 *|PB7     PA7|* 11 LED
//                        |___________|
//                      Attiny261/461/861
// 
// TEMPLATE / VORLAGE
// Funktionsbeschreibung:
// PB0-PB3 - Eingabe, PA0-PA3 Ausgabe
//
//******************************************************************************
// B. Redemann 2011, Freie Software
//******************************************************************************
	

void initPORTS(void)
{
// Ports einstellen
// Achtung! Wenn der Trimmer und der Kodierschalter best�ckt sind, m�ssen die
// Pins PB0 bis PB4 als Eingang konfiguriert werden. Sonst Kurzschlussgefahr! 
// Drehschalter (PB0-PB3), Potipin (PB4)auf Eingang, Rest Ausgang, Reset Eingang
DDRB = (0<<PB7 | 1<<PB6 | 1<<PB5 | 0<<PB4 | 0<<PB3 | 0<<PB2 | 0<<PB1 | 0<<PB0);
// Port A komplett auf Ausgang
DDRA = 0xff; // F�r LEDs

// Ausgangspins Port A auf 0 setzen (alle LEDs aus)
PORTA = 0x00;
}

	
int main (void)
{

initPORTS();

while (1)
{
PORTA =~PORTA;
_delay_ms(1024);
}

return 0;
}

