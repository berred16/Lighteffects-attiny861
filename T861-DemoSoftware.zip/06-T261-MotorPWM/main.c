#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

//******************************************************************************
// Universallauflicht mit Atiny261/461/861
// Anschlussbelegung:
//                         ____   ____
//       Drehschalter 8  *|PB0 \_/ PA0|* 20 LED
//       Drehschalter 4  *|PB1     PA1|* 19 LED
//       Drehschalter 2  *|PB2     PA2|* 18 LED
//       Drehschalter 1  *|PB3     PA3|* 17 LED
//                +5V 5  *|VCC     GND|* 16 GND
//                GND 6  *|GND    AVCC|* 15 +5V
//         Poti (ADC7)7  *|PB4     PA4|* 14 LED
//                PB5 8  *|PB5     PA5|* 13 LED
//                PB6 9  *|PB6     PA6|* 12 LED
//  (reset) +5V -10k- 10 *|PB7     PA7|* 11 LED
//                        |___________|
//                      Attiny261/461/861
// 
// TEMPLATE / VORLAGE
// Funktionsbeschreibung:
// PB0-PB3 - Eingabe, Werte werden �ber PA0-PA3 ausgegeben
//
//******************************************************************************
// B. Redemann 2011, Freie Software
//******************************************************************************


void initAD(void)
{
// ADC Section **************************************************************
// ADC an Port PB4 (ADC7)
// ADMUX: VREF=AVCC, ADLAR (left), ADC 7
// REFS1=0 REFS0=0 ADLAR=1 MUX4 MUX3 MUX2 MUX1 MUX0
//ADMUX = 0b00100111; oder
ADMUX = (0<<REFS1 | 0<<REFS0 | 1<<ADLAR | 0<<MUX4 | 0<<MUX3 | 1<<MUX2 | 1<<MUX1 | 1<<MUX0);
//
// ADCSRA: Enable, start convert, ohne Trigger, free running, prescalar 0b100 
// ADEN=1 ADSC=1 ADATE=1 ADIF=0 ADIE=0 ADPS2=1 ADPS1=0 ADPS0=0
// ADCSRA = 0b11100111; oder
ADCSRA = (1<<ADEN | 1<<ADSC | 1<<ADATE | 0<<ADIF | 0<<ADIE | 1<<ADPS2 | 0<<ADPS1 | 0<<ADPS0);
//
// ADCSRB wird auf 00 bleiben (default Wert, free running)
ADCSRB = 0x00;
// ADC Section end **********************************************************
}

void initPORTS(void)
{
// Ports einstellen
// Achtung! Wenn der Trimmer und der Kodierschalter best�ckt sind, m�ssen die
// Pins PB0 bis PB4 als Eingang konfiguriert werden. Sonst Kurzschlussgefahr! 
// Drehschalter (PB0-PB3), Potipin (PB4)auf Eingang, Rest Ausgang, Reset Eingang
DDRB = (0<<PB7 | 1<<PB6 | 1<<PB5 | 0<<PB4 | 0<<PB3 | 0<<PB2 | 0<<PB1 | 0<<PB0);
// Port A komplett auf Ausgang
DDRA = 0xff; // F�r LEDs

// Ausgangspins Port A auf 0 setzen (alle LEDs aus)
PORTA = 0x00;
}


int main(void)
{
  initAD();
  initPORTS();
  
  // PB0 auf Ausgang setzen
  DDRB = (1 << PB0) |(1 << PB1);
  
  //Timer 1 einstellen, Fast PWM (ca. 31kHz)
  // COM1A0 : Port PB0
  // PB0 und PB1 "spiegelverkehrtes" PWM
  TCCR1A = (1 << COM1A0) |(1 << WGM11) | (1 << WGM10);
  // Timer Prescaler 1 (CK)
  TCCR1B = (1 << CS10);
    
  while(1)
  {
  OCR1A = ADCH; // Potiwert dient als Vergleichswert, um PWM zu �ndern
  }
return 0;
}
